﻿Public Class Form1

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declare Variables

        Dim decTotalSpeed As Decimal
        Dim intFeetTraveled As Integer
        Dim blnInputOk As Boolean = True

        'Constant speed declaration


        Const decAIR_SPEED As Decimal = 1100
        Const decWATER_SPEED As Decimal = 4900
        Const decSTEEL_SPEED As Decimal = 16400

        'Check input

        If Integer.TryParse(txtNumberOfFeet.Text, intFeetTraveled) = False Then
            lblStatus.Text = "Feet traveled must be integer value."
            blnInputOk = False
        End If

        If intFeetTraveled < 1 Then
            lblStatus.Text = "Feet traveled must be greater than 1."
            blnInputOk = False
        End If

        If blnInputOk = True Then
            'Total speed determination
            If radAir.Checked = True Then
                decTotalSpeed = decAIR_SPEED
            ElseIf radWater.Checked = True Then
                decTotalSpeed = decWATER_SPEED
            ElseIf radSteel.Checked = True Then
                decTotalSpeed = decSTEEL_SPEED
            End If
            'Calculate speed of sound
            decTotalSpeed = decTotalSpeed * intFeetTraveled
            'Display outputs
            lblTotal.Text = decTotalSpeed.ToString("c")

        End If
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click


        'Reset
        radAir.Checked = False
        radWater.Checked = False
        radSteel.Checked = False

        'Clear number of feet
        txtNumberOfFeet.Clear()

        'Clear lables
        lblTotal.Text = String.Empty

        'Set the focus on number of months input
        txtNumberOfFeet.Focus()
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
    Private Sub StatusStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles StatusStrip1.ItemClicked

    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class